module.exports = {
	service: {
		name: 'wmf_regserver',
		endpoint: {
			url: 'http://localhost:4000/graphql',
		},
	},
}
