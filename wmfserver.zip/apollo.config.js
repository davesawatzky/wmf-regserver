module.exports = {
	service: {
		name: 'wmf_regserver',
		endpoint: {
			url: 'http://localhost/graphql',
		},
	},
}
