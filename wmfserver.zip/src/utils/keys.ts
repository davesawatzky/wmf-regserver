const JWT_SIGNATURE: string = 'flkssldkdwoehjndsfjkhashf'

export default JWT_SIGNATURE
